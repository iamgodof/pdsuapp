
// 以上getDatas函数优化
// params 接收网络请求的配置信息对象 
// header 请求头 get/GET 请求方式 "content-type:json" 
// post/POST 请求方式  "content-type:aplication/x-www-form-urlencoded"
function getDatas(params){
   // toLowerCase() 转化小写字母
   return new Promise((resolve,reject)=>{
      // 网络请求
      uni.request({
         ...params,
         header:{
            "content-type":params.method.toLowerCase() == "post" ? "aplication/x-www-form-urlencoded" : "json"
         },
         success:(res)=>{
          resolve(res);
         },
         fail:(err)=>{
          reject(err);
         }
       })
   })
}
// 封装一个或者多个axios网络请求,使用promise同步执行多个异步任务实现;
// 参数args 接收一个url接口的配置信息对象或者多个url配置信息对象的数组;
async function netWork(args){
    if (args instanceof Array) {//args是数组，说明多次请求
        let results = [];//用来存储多个请求回来的数据
        for(let index in args){
           let data = await getDatas(args[index]);//网络请求
           results.push(data);
        }
        return results;//返回数组中存储的数据
    } else {//一次请求，args是对象
       return await getDatas(args);
    }
}
export default netWork;//导出方法名