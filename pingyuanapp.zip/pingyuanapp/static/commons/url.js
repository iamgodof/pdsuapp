// 接口url的封装
// 使用条件编译,不同平台下执行不同的代码
// #ifdef H5
let base = "/api";//跨域请求
// #endif
// #ifndef H5
let base = "http://43.143.190.87:8082";
// #endif
let baseUrl = "http://gc.lsputao.com/index.php"; //域名
let urls = {
	firstUrl: baseUrl + "?s=/api/page/detail&pageId=0", //商城首页
	typesUrl: baseUrl + "?s=/api/category/list", //分类列表的数据
	goodsUrl: function(id) { //分类食品数据展示
		return baseUrl + `?s=/api/goods/list&categoryId=${id}&page=1`;
	},
	detailUrl: function(id) { //商品详情数据展示
		return baseUrl + `?s=/api/goods/detail&goodsId=${id}`;
	},
	cors(type, page) { //获取课程 type接收课程分类id page接收请求的页码数
		return {
			url: `${base}/napi/index/getcatec?sub=${type}&page=${page}&pageNum=10`,
			method: "get"
		}
	},
	codeUrl: baseUrl + "?s=/api/captcha/image", //图形验证码地址
	shopListUrl: function(type, num, keys) {
		return baseUrl +
			`?s=/api/goods/list&sortType=${type}&sortPrice=${num}&categoryId=0&goodsName=${keys}&page=1`
	}
}
export default urls;