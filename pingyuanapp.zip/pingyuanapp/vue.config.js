// 1.在当前项目根目录以下,创建vue.config.js文件,用来设置跨域代理
module.exports = {
	devServer:{
		proxy:{
			"/api":{
				target:"http://43.143.190.87:8082",//将要代理的域名
				changeOrigin:true,
				pathRewrite:{
					"^/api":""
				}
			}
		}
	}
}