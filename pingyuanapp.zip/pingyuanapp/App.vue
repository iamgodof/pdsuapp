<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		globalData:{//公共数据存储器 - 全局的数据，供所有组件访问
			corData:{},//存储当前的课程对象
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
