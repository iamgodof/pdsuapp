<template>
	<view>
		<!-- 显示课程对应的图片及内容部分 -->
		<image :src="'http://43.143.190.87:8082'+corObj.pic" mode="widthFix"></image>
		<!-- 显示课程上传的时间 -->
		<text class="time">{{corObj.time}}</text>
	</view>
</template>

<script>
	let app = getApp();
	export default {
		data() {
			return {//数据源
				corObj:{}
			}
		},
		onShow() {
		  // 接收公共数据源部分的数据
		  this.corObj = app.globalData.corData;
		  // 为导航条标题赋值
		  uni.setNavigationBarTitle({
		  	title:this.corObj.title
		  });
		},
		methods: {
			
		}
	}
</script>

<style>
	 image{
		 width: 750upx;
		 /* 去除图片底部的间隙 */
		 vertical-align: bottom;
	 }
	 .time{
		 float: right;
		 color: red;
		 padding: 5px 10px;
	 }
</style>
