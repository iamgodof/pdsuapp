<template>
	<view class="first">
		<!-- 搜索框部分 -->
		<view class="search">
			<!-- 图标部分 -->
			<icon type="search" size="13px" color="lightgray"></icon>
			<!-- 输入框 -->
			<input type="text" placeholder="请输入关键字进行搜索">
		</view>
	</view>
</template>

<script>
	export default {
		data() {//数据源
			return {
				shopMessage:{},//店铺公告
				swiperArr:[],//存储轮播图请求返回的数组
				navsList:[],//存储商品分类部分的数组
				newsComment:[] //存储新品推荐部分的数组
			}
		},
		onShow() {
			// 设置导航条标题
			uni.setNavigationBarTitle({
				title:"华衫商城"
			});
		},
		onLoad() {

		},
		created() {
			// 首页的网络请求
			this.getFirstData();
		},
		methods: {
			getFirstData(){
				// 加载动画
				uni.showLoading({
					title:"loading...",
					mask:false
				});
				// 调用网络请求的方法
				this.$request({
					url:this.$urls.firstUrl,
					method:"get"
				}).then(res=>{
					console.log(res);
					// 关闭加载动画
					uni.hideLoading({
						
					});
				});
			}
		}
	}
</script>

<style>
	/* 设置样式部分 */
	.first{
		background-color: rgba(0, 0, 0, 0.05);
		border: 1px solid transparent;
	}
	.search{
		width: 690upx;
		height: 26px;
		/* 左右居中 */
		margin: 10px auto;
		background-color: white;
		/* 首行缩进 */
		text-indent: 0.4em;
		padding: 3px 0;
		border-radius: 3px;
	}
	.search input{
		width: 620upx;
		height: 26px;
		font-size: 12px;
		color: gray;
		float: right;
	}
	
</style>
