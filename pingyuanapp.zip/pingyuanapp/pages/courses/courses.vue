<!-- 页面的内容部分 - 结构 -->
<template>
	<!-- uni-app 当中可以使用微信小程序中的组件(uni组件)，uni中的内置组件，以及扩展组件，必须使用vue中的相关指令及语法 -->
	<view>
		<!-- 显示课程相关的内容部分 -->
		<!-- 使用vue中的v-for指令遍历网络请求回来的数据源 -->
		<!-- 绑定一个点击事件，点击跳转到详情页面，并传值 -->
		<view @click="jumpDetail(item)" class="item" :key="index" v-for="(item,index) in cors">
			<!-- 图片部分 -->
			<image :src="'http://43.143.190.87:8082' + item.pic" mode="widthFix"></image>
			<!-- 课程题目 -->
			<view class="title">
				<text v-text="item.title"></text>
			</view>
			<!-- 正在学习的人数及课程售价 -->
			<view class="study">
				<text class="left">¥{{item.price}}</text>
				<text class="right">{{item.view}}人学习</text>
			</view>
		</view>
	</view>
</template>
<!-- 页面的交互部分 -->
<script>
	let app = getApp();//获取全局对象
	export default {
		data() {//数据源
			return {
				cors:[] //接收网络请求回来的课程数据
			}
		},
		created() {//组件创建完成的生命周期方法
			this.getDatas();//调用方法
		},
		methods: {//方法
			jumpDetail(v){//v接收item的值
				// 跳转到详情页面 uni.switchTab 跳转到tabbar 一级页面
				// uni.navigateTo 页面跳转 - 导航内
				uni.navigateTo({
					url:"../detail/detail"
				});
				// 将点击的当前课程对象 v,存储到公共存储器中
				app.globalData.corData = v;
			},
			getDatas(){
				// 加载动画
			   uni.showLoading({
			   	title:"加载中...",
				mask:false
			   });
			   // 网络请求
			   this.$request({
				   ...this.$urls.cors(3,1)
			   }).then(res=>{
				   console.log(res);
				   this.cors = res.data.data.courses;//为数据源赋值
				   // 关闭加载动画
				   uni.hideLoading({
					   
				   });
			   });
			}
		}
	}
</script>
<!-- 页面的样式部分 -->
<style>
	page{
		background-color: #d3d3d3;
	}
	.item{
		/* upx 是uni-app中的屏幕适配单位,将当前屏幕宽度平均分成750等份,所占的大小就是相对宽度 */
		width: 730upx;
		margin-left: 10upx;
		margin-top: 30upx;
		background-color: #FFFFFF;
		/* 截取边角 */
		border-radius: 30upx;
		/* 超出部分隐藏 */
		overflow: hidden;
	}
	/* 设置图片的样式 */
	.item image{
		width: 100%;
		/* 去除图片底部的间隙 */
		vertical-align: bottom;
	}
	/* 设置课程标题的样式 */
	.title{
		text-align: center;
		padding: 15px 0;
	}
	/* 课程价格及学习人数 */
	.study{
		padding-bottom: 20upx;
		margin-top: 10upx;
		/* 清除浮动造成的影响 */
		overflow: hidden;
	}
	.left{
		/* 左浮动 */
		float: left;
		color: red;
		margin-left: 40upx;
	}
	.right{
		/* 右浮动 */
		float: right;
		padding: 3px 8px;
		background-color: aqua;
		border-radius: 15upx;
		margin-right: 15upx;
	}
</style>
