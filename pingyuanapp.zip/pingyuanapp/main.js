import App from './App'
// mian.js 程序的入口交互文件
import Vue from 'vue'
import './uni.promisify.adaptor'

// 引入network及url文件 - 全局导入,供所有组件及页面使用
import netWork from './static/commons/netWorkRequest'
import urls from './static/commons/url'
Vue.prototype.$request = netWork;
Vue.prototype.$urls = urls;

Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
  ...App
})
app.$mount()

